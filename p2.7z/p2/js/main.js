var init = function() {
    // JS here is executed after DOM is ready
};

document.addEventListener('DOMContentLoaded', init);
