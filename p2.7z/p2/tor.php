<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="scripts/jquery.min.js"></script>
  <script src="scripts/popper.min.js"></script>
  <script src="scripts/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="scripts/validator.js"></script>
  <script src="scripts/contact.js"></script>
  <link rel="stylesheet" href="./css/follow.css">
  <style>
      img {
      border-radius: 5%;
    }
    div{
    margin-right: 90px;
    margin-left: 90px;
    text-align: justify;
    }

  </style>
	<title>
	
	</title>
</head>
<body style="background-color:lavender;">
  <br>
  <br><br>
  <div class="container" style="background-color:lavender;">
    <center>
        <a href = "./tor.php"><h1 class="display-4">Tor Anonymity</h1></a>
    </center>
    
  </div>
  <div class="container">
    <center>
      <img src="img/tor.png" height="100" width="150">
      <br>
    </center>                                             
<div>
<p align ="justify">Internet is much deeper. In fact, the World Wide Web as we know it represents just 4% of networked web pages  — the remaining 96% of pages make up what many  refer to as the “Deep Web”,“Invisible Internet,” or  “Invisible Web”. This massive subsection of the Internet is 500 times bigger than the visible Web and is not indexed by search engines like Google. The content of the deep web is hidden behind the HTML forms. So, basically the 4% of the web that a search engine can access is the Surface Web. The 96% of the web that a search engine can’t access is referred to as the Deep Web. The Dark Web then is classified as a small portion of the Deep Web that has been intentionally hidden and is inaccessible through standard web browsers. In order to access the Deep Web, we need to use a dedicated browser. Tor is the most commonly used, but I2P and Freenet provide an alternative solution to Tor.</p>

<p>Tor is a free software that aims to provide anonymous communication between entities on a network. It is short for “The Onion Router”. Tor was originally developed by the U.S. Navy with the purpose of protecting U.S. government communications during intelligence operations. Tor network conceals our identity by moving the internet traffic over different Tor servers, which are actually other people’s computers. It’s goal is to provide low latency connections transparent to the end user, while the information exchange still is resistant against traffic analysis and other attacks. This is achieved by a set of encrypted layers and frequently changing paths between a subset of the routers that participates in the routing system.</p>

<center>
      <img src="img/sas.jpg">
      <br>
</center>

<p>Tor installs directly into the web browsers and establishes the connections needed to access Deep Web sites. The above image shows how a Tor network works. Our data is bundled into encrypted packets before it enters the Tor network. After this, Tor takes off part of this packet’s header, which includes information like the source, size, destination and timing, all of which can be used to learn things about the sender. Next, Tor encrypts the rest of the information, which a normal internet connection cannot do. Finally, the encrypted data is sent through many of the servers (called relays) randomly, each of which decrypts and then re-encrypts just enough of the data to know where it came from and where it is going next. The encrypted address layers used to anonymize data packets that are sent through the Tor network are like an onion, thus the name. The Visible Web functions off of commonly known domains: .com, .org, .net. Tor allows for access to the Deep Web with page domains .onion.</p> 

<p>The most common argument against tools for anonymous communication is that criminals can use it to plan future crimes, exchange illegal content etc. without revealing themselves. For an  example identity theft is becoming more and more common among people with dark intentions and criminals already have means to hide their identity while ordinary people don’t.</p>
<p>A well known example for this argument —To make black market purchases, users utilize Bitcoin. For the purposes of this content, Bitcoin is the black market currency of choice. While Bitcoin has beneficial purposes, the story of the currency will not be told here. This is just a single example. The various reasons to use Tor are to avoid being tracked by advertising companies on the Web, reach Internet services and sites blocked by the ISP or participating in chat rooms for victims of all kinds of abuse. Also, Government agencies use Tor for intelligence gathering and people in different countries without freedom of speech use it to communicate with other freedom seekers.</p>

<p>The most immediate noticeable drawback to Tor, is its performance. The fact that the data goes through many relays makes it very sluggish, especially when it comes to audio and video. It is also important to know that using Tor is infact vulnerable. In fact, many believe Tor to be fairly easily hackable, as exit nodes can see your traffic if the site you are accessing does not use SSL. Due to the anonymity provided by the Tor, the deep web has been popular nesting ground for criminal activities like drugs, child pornographies, weapons trading, hiring hit men,etc.</p>  

<p>The Tor software protects us by bouncing our communications around a distributed network of relays run by volunteers all around the world: it prevents somebody watching our Internet connection from learning what sites we visit, it prevents the sites we visit from learning our physical location, and it lets us access sites which are blocked. Anything we do on this browser is safe from the prying eyes of the government, hackers, Google Ads and other advertisers. </p>

<p>We are the one responsible for what we do on the internet. Hence, we must be diligent on deciding how we conduct ourselves on the internet.</p>
</div>    

</body>

</html>