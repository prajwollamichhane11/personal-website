<?php

// variable declaration
$name = "";
$email    = "";
$errors = array();

// connect to database
$db = mysqli_connect('localhost', 'root', '','website');


// REGISTER USER
if (isset($_POST['con_me'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['fname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  
  // form validation: ensure that the form is correctly filled
  if (empty($name)) { array_push($errors, "Full name is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
 
  // register user if there are no errors in the form
  if (count($errors) == 0) {
 
    $query = "INSERT INTO contact (name, email)
  			  VALUES('$name', '$email')";

  	$s = mysqli_query($db, $query);

    if ($s == false){
      array_push($errors, "Name or Email failed to contact.");
      header('location:index.php');
    }
    else{
  	echo "Logged in";
    header('location: index.php');
    exit();
    }
  }
}
?>