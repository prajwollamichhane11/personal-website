<html>
<head></head>
<title>Contact</title>
<body>
<?php include "header.html"?>
<form method="POST" enctype="multipart/form-data" action = "contact.php">
  	<label>Name</label>
    <input type="name" name="name">
    
  	<label>Email</label>
    <input type="email" name="email">
    <br><br>
	<label>Feedbacks</label>
      <textarea 
        id="text" 
        cols="40" 
        rows="6" 
        name="feedback" 
        placeholder="Enter feedbacks"></textarea>
    <br>
    <br>
    <div>
  	  <p align="center"><button type="submit" class="btn" name="con_me" >Contact Me</button></p>
  		
  	</div>
</body>
</html>