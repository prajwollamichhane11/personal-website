<!DOCTYPE html>
<html>
<head>
  <title>Prabhat Dahal</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../scripts/jquery.min.js"></script>
  <script src="../scripts/popper.min.js"></script>
  <script src="../scripts/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="scripts/validator.js"></script>
  <script src="scripts/contact.js"></script>
  <link rel="stylesheet" href="./css/follow.css">
	<style>
	  	a:hover {
	    color: green;
	    }
		img {
	  	border-radius: 7%;
		}
</style>
	<title></title>

</head>
<body style="background-color:lavender;">
	
	<br><br><br>
	<center>
		<h2>
			Blogs
		</h2>
	</center>

	<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<br>
				<img src="img/ss.jpg"  style="width:300px;height:150px;">
			</div>
			<div class="col-sm-8">
				<strong><h3><a href="./tor.php">Mobile And Internet</a></h3></strong><br>
				<p>The microprocessor and cheap memory revolutionized the communication industry in the 1980s after mobile was born on 1970s.  Development of web in 1990s has become another revolution in communications industry. These factors were in verge of making this world a small place to be in. By 2000 the price of international telephone calls cost a fraction of what they had fifteen years earlier, further enhancing the globalization. Torrents of data pulsed through global digital networks, and the ways people communicated was transformed. Communications and information technology is now at the core of a new world information economy. As globalization proceeds we need to understand why global networking grew as it did.</p>

				<br>
				<a href="tor.php">
					<button type="button" class="btn btn-success">Read More</button>
				</a>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-sm-4">
				<a href ="tor.php"><img src="img/tor.png"  style="width:200px;height:250px;"></a>
			</div>
			<div class="col-sm-8">
				<strong><h3><a href="tor.php">Tor Anonymity</a></h3></strong><br>
				Internet is much deeper. In fact, the World Wide Web as we know it represents just 4% of networked web pages  — the remaining 96% of pages make up what many  refer to as the “Deep Web”,“Invisible Internet,” or  “Invisible Web”. This massive subsection of the Internet is 500 times bigger than the visible Web and is not indexed by search engines like Google. The content of the deep web is hidden behind the HTML forms.
				<br>
				<br>
				<a href="tor.php">
					<button type="button" class="btn btn-success">Read More</button>
				</a>
			</div>
		</div>
		<hr>
	</div>
	
</body>
</html>