<?php include 'header.html'?>
    <section class="main">
        <div class="container">
            <img src="./prabhat.jpeg" class="photo">
            <div class="name-section">
                <div class="name">Prabhat Dahal</div>
                <div class="tagline">Student at Islington College</div>
            </div>
        </div>
    </section>
    
  <?php include 'footer.html'?>
</body>
</html>
