<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="The personal webpage of Prabhat Dahal">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <title>Prabhat Dahal</title>
    <link rel="stylesheet" type="text/css" href="./css/main.css">
    <link rel="icon" type="image" 
          href="./prabhat.jpeg">
</head>
<body>
<?php include 'header.html'?>
    <section class="main">
        <div class="container">
            <img src="prabhat.jpeg" class="photo">
            <p class="about">
                My name is Prabhat Dahal, and i am very passionate about technology. I always try to find ways to uplift my experience. People find me to be an upbeat, self-motivated team player with excellent communication skills. My Experience includes YEHA AFNU EXPERIENCE HARU GUFF HANNU.

                <br>
                <p align = "justify"><a href = "https://drive.google.com/open?id=1WMOvYCvi1oMzJXS5tPi9fNkGPVQR9Q25"> Download My Resume</a></p>
            </p>
        </div>
    </section>
 <?php include 'footer.html'?>   
</body>
</html>
